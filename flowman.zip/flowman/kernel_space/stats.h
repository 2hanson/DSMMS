
typedef struct 
{
   unsigned long s_addr;
   unsigned long d_addr; 
   unsigned short sport;
   unsigned short dport;
   char ifname[12];
   unsigned short flowID;
   unsigned char status;
   unsigned char protocol;	/*TCP/UDP/ICMP/OTHER*/
} FlowInfo;  

int get_flow_info(manager* pmng, const char __user * buffer, char * local_buf, size_t length)
{
    int count = 0, maxcount = 0;
    int i = 0;
    int total_len = 0;
	int isall = 1;
	man_entry * tmp;
    FlowInfo* flow_ptr;
	
	if(length < 2*sizeof(int))
	{
		printk("get_flow_info(): user buff length is to small!\n");
		goto end;
	}

	length = length < LONG_BUF_LEN ? length : LONG_BUF_LEN;
    maxcount = (length - 2*sizeof(int)) / sizeof(FlowInfo);

    flow_ptr = (FlowInfo*)(local_buf + 2*sizeof(int));

    for ( ; i < MAN_TABLE_SIZE; i++)
 	{
		if (!pmng->table[i].tag) 	
		{
             continue;
	    }
		tmp = &(pmng->table[i]);
		while (tmp) 
	    {
			if(count >= maxcount)
			{
				isall = 0;
				goto out;
			}

			flow_ptr->s_addr = tmp->s_ipv4;
	        flow_ptr->d_addr = tmp->d_ipv4;
            flow_ptr->sport = tmp->sport;
            flow_ptr->dport = tmp->dport;
	        flow_ptr->protocol = tmp->protocol;
			flow_ptr->flowID = tmp->id;
			flow_ptr->status = tmp->tag;
			//flow_ptr->ifname = tmp->ifname;
			strncpy(flow_ptr->ifname, tmp->ifname, sizeof(flow_ptr->ifname)-1);
			tmp = tmp->next;
			count++;
			flow_ptr++;
            //printk("get_flow_info(): flow_ptr->ifname: %s\n",flow_ptr->ifname);
	    }
	} 

out:
    *((int*) local_buf) = count;
    *((int*) local_buf + 1) = isall;
    total_len = count*sizeof(FlowInfo) + 2*sizeof(int);
    local_buf[total_len] = '\0';

	count = copy_to_user((void *)buffer, local_buf, total_len);
end:
	;
}
