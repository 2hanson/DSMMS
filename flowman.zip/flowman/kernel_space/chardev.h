/*
 * Create an input/output character device
 * A read buffer and a write buffer are established to avoid data collision
 * Message parsing to implement functions such as switch open/close.
*/
#ifndef __KERNEL__
#define __KERNEL__
#endif

#include <linux/kernel.h>	/* We're doing kernel work */
#include <linux/module.h>	/* Specifically, a module */
#include <linux/string.h>	/* char process methods */
#include <linux/fs.h>
#include <linux/spinlock.h>
#include <asm/uaccess.h>	/* for get_user and put_user */
#include <linux/types.h>
#include <linux/kdev_t.h>
#include <linux/cdev.h>
#include <linux/device.h>

#ifndef _CHARDEV_H_
#define _CHARDEV_H_

#include <linux/ioctl.h>
//#include <linux/syscalls.h>

/* 
* The major device number. We can't rely on dynamic 
* registration any more, because ioctls need to know 
* it. 
*/
#define MAJOR_NUM 241


#define IOCTL_GET_OUT_FLOWINFO _IOR(MAJOR_NUM, 1, char *)

#define IOCTL_GET_IN_FLOWINFO _IOR(MAJOR_NUM, 2, char *)


/* 
* The name of the device file 
*/
#define SUCCESS 0
#define DEVICE_NAME "android_chardev"
#define BUF_LEN 512
#define LONG_BUF_LEN 3000
#define U32BUF 5

#endif 

#include "stats.h"
extern manager in_flowman,out_flowman;


/* 
* Is the device open right now? 
* Used to prevent concurent access into the same device 
*/
static int isopen = 0;

/* Buffers for our device as basic charicteristics.
 * But unfortunately, we don't actually use them */
char read_buf[BUF_LEN];
char write_buf[BUF_LEN];
char local_buf[LONG_BUF_LEN];

/* 
* This is called whenever a process attempts to open the device file 
*/
static int device_open(struct inode *inode, struct file *file)
{
    /* This device should be open at most once at the same time. */
    if (isopen)
    {
		return -EBUSY;
    }
	isopen = 1;
  /* Initialize the message */
    try_module_get(THIS_MODULE);
    return SUCCESS;
}

/* release the device */
static int device_release(struct inode *inode, struct file *file)
{
	/* We're now ready for our next caller */
    isopen = 0;
    module_put(THIS_MODULE);
    return SUCCESS;
}


/* 
* This function is called whenever a process which has already opened the
* device file attempts to read from it.
*/
static ssize_t device_read(struct file *file,	/* see include/linux/fs.h   */
			   char __user * buffer,	/* buffer to be filled with data */
			   size_t length,		/* length of the buffer     */
			   loff_t * offset)
{
	int ret = 0;
	
    /* Number of bytes actually written to the buffer */
    int read_bytes = strlen(read_buf);
    

    /* put_user is usually used to pass a single varible */
    ret = copy_to_user(buffer, read_buf, read_bytes + 1);

	/* Read functions are supposed to return the number of bytes 
	actually inserted into the buffer */
    return read_bytes;
}

/* generic write command */
static ssize_t
device_write(struct file *file,
	     const char __user * buffer, size_t length, loff_t * offset)
{
	int ret = 0;
    int write_bytes = strlen(buffer);
    ret = copy_from_user(write_buf, buffer, write_bytes + 1);
    return write_bytes;

}

int device_ioctl(struct inode *inode,	/* see include/linux/fs.h */
		 struct file *file,	/* ditto */
		 unsigned int ioctl_num,	/* number and param for ioctl */
		 unsigned long ioctl_param)
{
    char *temp;
    temp = (char *) ioctl_param;
	switch(ioctl_num)
	{
		case IOCTL_GET_OUT_FLOWINFO: 
			get_flow_info(&out_flowman, temp, local_buf, LONG_BUF_LEN);
			break;
        case IOCTL_GET_IN_FLOWINFO: 
			get_flow_info(&in_flowman, temp, local_buf, LONG_BUF_LEN);
            break;
		default:
			printk("Char Device: Unknown command!\n");
	}
    return SUCCESS;
}



struct file_operations Fops = {
    .read = device_read,
    .write = device_write,
    .ioctl = device_ioctl,
    .open = device_open,
    .release = device_release,
};


/* 
* Initialize the module - Register the character device 
*/
struct class *my_class;

int init_chardevice(void)
{
	int rs;  
	rs = register_chrdev(MAJOR_NUM, DEVICE_NAME, &Fops);
	if(rs < 0)
		return rs;
	my_class = class_create(THIS_MODULE,"chardev");
	if(IS_ERR(my_class))
    {
		printk("Err:failed in creating class......!\n");
		return -1;
    }
	device_create(my_class,NULL,MKDEV(MAJOR_NUM,0),NULL,"chardev");
//	sys_chmod("/dev/chardev", 0644);
	printk("chardev OK......\n");
	return 0;
}


void clean_chardevice(void)
{
	device_destroy(my_class,MKDEV(MAJOR_NUM,0));
	class_destroy(my_class);  
	unregister_chrdev(MAJOR_NUM, DEVICE_NAME);
}
