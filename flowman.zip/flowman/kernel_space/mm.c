/*
 * This program is a Linux Loadable Kernel Module
 * tying to solve problems as follow:
 *   1) At LOCAL_OUT points, filter packets, identify packet type, 
        make a record of packets
 *   2) At LOCAL_IN points, monitor the packets for handoff notification
 * This program is available on Linux 2.6.29 Fedora 8
*/ 
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/netfilter.h>
#include <linux/ip.h>
#include <linux/netfilter_ipv4.h>
#include <asm/atomic.h>
#include <linux/string.h>
#include <linux/sched.h>
#include <linux/workqueue.h>
#include <linux/netdevice.h>
#include "manager.h"
#include "chardev.h"
/* ---------------- GNU lisence ---------------- */
    MODULE_LICENSE("GPL");
    MODULE_AUTHOR("zhangyangyang");
/* ---------------- Hook Function Declararions ---------------- */ 
 unsigned int HOOK_local_in(unsigned int hooknum,
				struct sk_buff *skb,
				const struct net_device *in,
				const struct net_device *out,
				int (*okfn) (struct sk_buff *));

 unsigned int HOOK_local_out(unsigned int hooknum,
				struct sk_buff *skb,
				const struct net_device *in,
				const struct net_device *out,
				int (*okfn) (struct sk_buff *));

struct nf_hook_ops nfho_ip_in = { list:{NULL,NULL},
hook: HOOK_local_in, hooknum: NF_INET_LOCAL_IN, pf:PF_INET,
priority:   NF_IP_PRI_FIRST, 
};

struct nf_hook_ops nfho_ip_out = { list:{NULL,NULL},
hook: HOOK_local_out, hooknum: NF_INET_LOCAL_OUT, pf:PF_INET,
priority:  NF_IP_PRI_FIRST, 
};

/********************************/
manager in_flowman,out_flowman;
int refresh_enable = 1;
int reg[2];
struct workqueue_struct *man_workq;
struct delayed_work man_work;
/********************************/

unsigned int 
HOOK_local_in(unsigned int hooknum, struct sk_buff *skb, 
								const struct net_device *in, const struct net_device *out, 
								int (*okfn) (struct sk_buff *)) 
{ 
 __u8 man_check = 0;
 unsigned long flag;
 spin_lock_irqsave(&in_flowman.lock,flag);
 man_check = manager_update_in_hash_skb(&in_flowman,skb,in->name);
 spin_unlock_irqrestore(&in_flowman.lock,flag);
 return NF_ACCEPT; 
}


unsigned int 
HOOK_local_out(unsigned int hooknum, struct sk_buff *skb, 
									const struct net_device *in, const struct net_device *out, 
									int (*okfn) (struct sk_buff *)) 
{
 __u8 man_check = 0;
 unsigned long flag;
 spin_lock_irqsave(&out_flowman.lock,flag);
 man_check = manager_update_out_hash_skb(&out_flowman,skb,out->name);
 spin_unlock_irqrestore(&out_flowman.lock,flag);
 return NF_ACCEPT;
}

void  man_refresh(struct work_struct *work) 
{
	while (refresh_enable)
	{
		manager_refresh_hash(&in_flowman);
		manager_refresh_hash(&out_flowman);
		msleep_interruptible(REFRESH_INTERVAL);	
 	}
}

/* module initilizer */ 
int  android_init(void)//init_module() 
{
        int result;
        refresh_enable = 1;
       
		/* manager init */
		manager_init(&in_flowman);
        manager_init(&out_flowman);
        
		/* chardev init*/
		if(init_chardevice() < 0)
        {
			printk(KERN_ERR "can not register such device!\n");
        }
        else
           printk("char device register successful!\n");
       
		/* locol hook in init */
	   	result = nf_register_hook(&nfho_ip_in);
        if (result) 
        {
			printk(KERN_ERR "Netfilter Platform: can't register local_in\n");
            return result;	
        }
        reg[0] = 1;
       
		/* locol hook out init */
		result = nf_register_hook(&nfho_ip_out);
    	if (result)
		{
			printk(KERN_ERR "Netfilter Platform: can't register local_out\n");
			return result;
		}
        reg[1] = 1;

        //initialize workqueue
		man_workq = create_singlethread_workqueue("man_workq");
    	INIT_DELAYED_WORK(&man_work, man_refresh); 
        queue_delayed_work(man_workq, &man_work, 2*HZ);

		printk("----- Netfilter Platform Opened-----\n");
		return 0;
}

/* module canceler */
void android_exit(void)//cleanup_module() 
{	
	manager_destroy(&in_flowman);
    manager_destroy(&out_flowman);
    if(reg[0] == 1)
	{
		nf_unregister_hook(&nfho_ip_in);
		printk("hook LOCAL_IN unistall ok\n");
	}

    if(reg[1] == 1)
	{
		nf_unregister_hook(&nfho_ip_out);
        printk("hook LOCAL_OUT unistall ok\n");
    } 
	/*destroy work and workqueue*/
    cancel_rearming_delayed_work(&man_work);
    destroy_workqueue(man_workq);
    printk("Now ready to close the char device.\n");
    clean_chardevice();
	printk("----- Netfilter Platform Closed-----\n");
}


module_init(android_init);
module_exit(android_exit);
