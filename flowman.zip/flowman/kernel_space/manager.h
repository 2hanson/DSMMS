#include <linux/string.h>
#include <linux/skbuff.h>
#include <linux/ip.h>
#include <linux/spinlock.h>
#include <linux/types.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/skbuff.h>
#include <linux/delay.h>
#include <linux/jiffies.h>	/* 250 jiffies == 1 second */
#define MAN_TABLE_SIZE 			7
/* manager entry status */
#define MAN_NOT_USE 				0x00
#define INUSE_AND_ACTIVE 		0x88
#define MAN_IN_USE 					0x80
#define MAN_ACTIVE 					0x08
#define MAN_ERROR 					0x20
/* entry protocol type, corresponds with definitions in <linux/socket.h> */
#define MAN_PROTO_ICMP 			0x01
#define MAN_PROTO_TCP 			0x06
#define MAN_PROTO_UDP 			0x11
#define MAN_PROTO_OTHER 	0xff
#define MAN_PROTO_NULL		0x00
//#define GET_IP_BUFSIZE 			16
#define EXPIRE_ACTIVE				1 * HZ
#define EXPIRE_VALID				2 * HZ
#define REFRESH_INTERVAL 	1000		/* measured in mini-second */
typedef struct man_entry_ 
{ 
	struct 	man_entry_ *next;	/* next entry if synonym collides*/
	__be32 s_ipv4;
  	__be32 d_ipv4;
    __u16  sport;		
	__u16  dport;
    __u32  last_ts;                 /*time stamp of the latest update*/
    char ifname[32];
	__u16  id; 		        /* this id makes flow infomation extraction much easier, ONLY can be incremented */
   	__u8   tag;			/* valid tag: this entry is in use or free */
  	__u8   protocol;		/*only be TCP, UDP and Other */
} man_entry;

typedef struct 
{
	man_entry table[MAN_TABLE_SIZE];
 	int valid_num;
 	spinlock_t lock;/* spinlock for exclusive access to this table */
 	__u16 next_id;
} manager;

void man_entry_init(man_entry * me) 
{   
    me->tag = MAN_NOT_USE;
    me->s_ipv4 = (__be32) 0;
    me->d_ipv4 = (__be32) 0;
    me->sport = (__u16) 0;
    me->dport = (__u16) 0;
    //me->ifname = NULL;
	memset(me->ifname, 0, sizeof(me->ifname));
    me->protocol = MAN_PROTO_NULL;
    me->next = (man_entry*) NULL;
} 

void manager_init(manager * pmng) 
{
	int i = 0;
    pmng->valid_num = 0;
	pmng->next_id = (__u16) 1;
   	spin_lock_init(&(pmng->lock));
    for (; i < MAN_TABLE_SIZE; i++)
	{
		man_entry_init(&(pmng->table[i]));
    }
}

void manager_destroy(manager * pmng)
{   int i = 0;
    man_entry * tmp, *link;
    for (; i < MAN_TABLE_SIZE; i++)
	{
		link = (pmng->table[i]).next;
		while (link)
	    {
	       tmp = link->next;
	       kfree(link);
	       link = tmp;
	    }
	}
}

inline int hash(__be32 ip) 
{
    long int tmp = 0;
    int ret;
    tmp += (int) ip;
    ret = ((int) tmp) % MAN_TABLE_SIZE;	
    return ((ret >= 0) ? ret : (-ret));
}

//inline __u8 get_protocol(struct iphdr * iph)
inline __u8 get_protocol(struct sk_buff * skb)
{
    struct iphdr *iph = ip_hdr(skb) ;
    __u8 origial_proto = iph->protocol;
    return (origial_proto == MAN_PROTO_TCP || origial_proto == MAN_PROTO_UDP || origial_proto == MAN_PROTO_ICMP) ? origial_proto : MAN_PROTO_OTHER;
}

__u8 manager_update_out_hash_skb(manager * pmng, struct sk_buff *skb, const char *ifname) 
{   
    man_entry * newen, *tmp, *tmpnext;
    unsigned char *trans;
	__be32 s_ipv4,d_ipv4;
    __u16 sport,dport;
    int hashkey;
    
	struct iphdr *iph = ip_hdr(skb);
    //trans = skb->data + sizeof(struct iphdr);
    trans = (char *)iph + (iph->ihl<<2);
    
	d_ipv4 = iph->daddr;
    s_ipv4 = iph->saddr; 
    /****************************************************/
	printk("d_addr(out): 0x%x\n",ntohl(d_ipv4));
	printk("ip->protocol (out): 0x%x\n",iph->protocol);
    /****************************************************/

	if(iph->protocol == MAN_PROTO_ICMP)
    {
       sport = 0;
       dport = 0;
    }
    else
    {
       sport = *(__u16 *)(trans);
       dport = *(__u16 *) (trans + 2);
    }
    hashkey = hash(d_ipv4);
    tmp = &(pmng->table[hashkey]);	/* get the entry */
    if (!tmp->tag) 	
       {		
        tmp->s_ipv4 = s_ipv4;
        tmp->d_ipv4 = d_ipv4;
        tmp->sport = sport;
        tmp->dport = dport;
        tmp->last_ts = jiffies;
        //tmp->ifname = ifname;
		strncpy(tmp->ifname, ifname, sizeof(tmp->ifname)-1);
		tmp->tag = MAN_IN_USE | MAN_ACTIVE;
		tmp->protocol = get_protocol(skb);
		tmp->next = (man_entry*) NULL;
		tmp->id = pmng->next_id++;
        
		return 0;
	}
    tmpnext = tmp;	
	do
	{
		tmp = tmpnext;
		tmpnext = tmp->next;
		if (tmp->s_ipv4 == s_ipv4 && tmp->d_ipv4 == d_ipv4 && tmp->sport == sport && tmp->dport == dport)		
        {
			tmp->last_ts = jiffies;
            tmp->tag = MAN_IN_USE | MAN_ACTIVE;
			return 0;
	    }	
    }while (tmpnext);
    
	newen = (man_entry *) kmalloc(sizeof(man_entry), GFP_ATOMIC);
    if (!newen)
	{
		printk(KERN_ERR "Can not allocate new entry for hash table.\n");
	    return MAN_ERROR;
	} 
	newen->id = pmng->next_id++;
    newen->next = NULL;
    newen->tag = MAN_IN_USE | MAN_ACTIVE;
	newen->s_ipv4 = s_ipv4;
    newen->d_ipv4 = d_ipv4;
	newen->sport = sport;
    newen->dport = dport;
    newen->last_ts = jiffies;
	//newen->ifname = ifname;
	strncpy(newen->ifname, ifname, sizeof(newen->ifname)-1);
    newen->protocol = get_protocol(skb);
	tmp->next = newen;
    return 0;
}

__u8 manager_update_in_hash_skb(manager * pmng, struct sk_buff *skb, const char *ifname) 
{
    man_entry * newen, *tmp, *tmpnext;
    unsigned char *trans;
    __be32 s_ipv4,d_ipv4;
    __u16 sport,dport;
    int hashkey;
    
	struct iphdr *iph = ip_hdr(skb);
    //trans = skb->data + sizeof(struct iphdr);
    trans = (char *)iph + (iph->ihl<<2);
    d_ipv4 = iph->daddr;
    s_ipv4 = iph->saddr; 
   // printk("in devname: %s\n",ifname);
    /****************************************************/
	printk("s_addr(in): 0x%x\n",ntohl(s_ipv4));
	printk("ip->protocol (in): 0x%x\n",iph->protocol);
    /****************************************************/
    if(iph->protocol == MAN_PROTO_ICMP)
    {
		sport = 0;
		dport = 0;
    }
    else
    {
		sport = *(__u16 *)(trans);
		dport = *(__u16 *) (trans + 2);
    }
    hashkey = hash(s_ipv4);
    tmp = &(pmng->table[hashkey]);	/* get the entry */
  
    if (!tmp->tag) 
    {			
		tmp->s_ipv4 = s_ipv4;
        tmp->d_ipv4 = d_ipv4;
        tmp->sport = sport;
        tmp->dport = dport;
        tmp->last_ts = jiffies;
		//tmp->ifname = ifname;
		strncpy(tmp->ifname, ifname, sizeof(tmp->ifname)-1);
        tmp->tag = MAN_IN_USE | MAN_ACTIVE;
		tmp->protocol = get_protocol(skb);
		tmp->next = (man_entry*) NULL;
		tmp->id = pmng->next_id++;
        return 0;
	}	
    tmpnext = tmp;
	do
	{	
		tmp = tmpnext;	
		tmpnext = tmp->next;
		if (tmp->s_ipv4 == s_ipv4 && tmp->d_ipv4 == d_ipv4 && tmp->sport == sport && tmp->dport == dport) 		
        {			
			tmp->last_ts = jiffies;
            tmp->tag = MAN_IN_USE | MAN_ACTIVE;
			return 0;
	    }	
    }while (tmpnext);
   
	newen = (man_entry *) kmalloc(sizeof(man_entry), GFP_ATOMIC);
    if (!newen)
	{
		printk(KERN_ERR "Can not allocate new entry for hash table.\n");
		return MAN_ERROR;	
    } 
	newen->id = pmng->next_id++;	
    newen->next = NULL;	
    newen->tag = MAN_IN_USE | MAN_ACTIVE;
	newen->s_ipv4 = s_ipv4;
    newen->d_ipv4 = d_ipv4;
	newen->sport = sport;
    newen->dport = dport;
    newen->last_ts = jiffies;
	//newen->ifname = ifname;
	strncpy(newen->ifname, ifname, sizeof(newen->ifname)-1);
    newen->protocol = get_protocol(skb);
	tmp->next = newen;
    return 0;
}

void manager_refresh_hash(manager * pmng) 
{
    int i;
    int tmp_count;
    unsigned long flags;
    man_entry * tmp, *tmpnext;
    spin_lock_irqsave(&(pmng->lock), flags);       
    for (tmp_count = 0, i = 0; i < MAN_TABLE_SIZE; i++)
 	{
		if (MAN_NOT_USE == pmng->table[i].tag) //modified by qcc
        {	
			continue;
	    }
		tmp = &(pmng->table[i]);
		/* added by qcc to correct a link bug. 2012/3/20*/
		tmpnext = tmp->next;
		//while ((tmpnext = tmp->next))
		/*********************************/
		while (tmpnext)
	    {
			if (jiffies - tmpnext->last_ts > EXPIRE_VALID)
	        {
				tmp->next = tmpnext->next;
	    	    kfree(tmpnext);
	    	    tmpnext = tmp->next;
	    	    continue;
	   	    }
			else if (jiffies - tmpnext->last_ts > EXPIRE_ACTIVE)
	   	    {
				tmpnext->tag = MAN_IN_USE;
	 	    }
	        tmp = tmpnext;
           	tmpnext = tmpnext->next;
	 	}
	 	// refresh table entry
		tmp = &(pmng->table[i]);
		if (jiffies - tmp->last_ts > EXPIRE_VALID)
        {
			if ((tmpnext = tmp->next))
			{
				memcpy(tmp, tmpnext, sizeof(man_entry));
				kfree(tmpnext);
	        }
			else
			{
				tmp->tag = MAN_NOT_USE;
				tmp->next = NULL;
			}
		}
		else 
		{
			if (jiffies - tmp->last_ts > EXPIRE_ACTIVE)
		    {
				tmp->tag = MAN_IN_USE;
		    }
	 	}
	} //end of for
	spin_unlock_irqrestore(&(pmng->lock), flags);

}

