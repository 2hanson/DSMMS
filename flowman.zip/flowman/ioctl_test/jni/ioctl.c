#include <string.h>
#include <sys/ioctl.h>                /* ioctl */
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>   
#include <arpa/inet.h>               //for inet_ntop
#include "chardev.h"                 //chardevice


#define LONG_BUF_LEN 3000
typedef struct 
{
   unsigned long s_addr;
   unsigned long d_addr; 
   unsigned short sport;
   unsigned short dport;
   char ifname[12];
   unsigned short flowID;
   unsigned char status;
   unsigned char protocol;	/*TCP/UDP/ICMP/OTHER*/
} FlowInfo;  

static int charDevFd;

void update_outflow()
{
	char addr[20],buffer[30];       
	char msg[LONG_BUF_LEN];
    int i;
	//system("insmod /data/module_main.ko");
	charDevFd = open("/dev/chardev", O_RDONLY);
	//printf("[out flow]charDevFd: %d\n",charDevFd);

	ioctl(charDevFd,IOCTL_GET_OUT_FLOWINFO, msg);
	close(charDevFd);

    int totalNum = *(int*)msg;
	printf("[out flow]count: %d\n\n",totalNum);
	
	FlowInfo *start = (FlowInfo*)(msg + 2*sizeof(int));	// add two sizeof(int). qcc 2012/3/20
	for (i = 0; i < totalNum; i++, start++)		//add start++. qcc
	{
		memset(addr,0, sizeof(addr));
		inet_ntop(AF_INET,&(start->d_addr),addr,sizeof(addr));
        printf("\t[out flow]dest addr: %s\n",addr);  
        printf("\t[out flow]dest port: %d\n",ntohs(start->dport));  
        printf("\t[out flow]device : %s\n",start->ifname);   
        printf("\t[out flow]ID: %u\n",start->flowID);   
        printf("\t[out flow]protocol: 0x%x\n\n",start->protocol);   
	}
}

void update_inflow()
{
	char addr[20],buffer[30];       
	char msg[LONG_BUF_LEN];
    int i;
	//system("insmod /data/module_main.ko");
	charDevFd = open("/dev/chardev", O_RDONLY);
	//printf("[in flow]charDevFd: %d\n",charDevFd);

	ioctl(charDevFd,IOCTL_GET_IN_FLOWINFO, msg);
	close(charDevFd);

    int totalNum = *(int*)msg;
	printf("[in flow]count: %d\n\n",totalNum);
	
	FlowInfo *start = (FlowInfo*)(msg + 2*sizeof(int));	// add two sizeof(int). qcc 2012/3/20
	for (i = 0; i < totalNum; i++, start++)		//add start++. qcc
	{
		memset(addr,0, sizeof(addr));
		inet_ntop(AF_INET,&(start->s_addr),addr,sizeof(addr));
        printf("\t[in flow]src addr: %s\n",addr);  
        printf("\t[in flow]src port: %d\n",ntohs(start->sport));  
        printf("\t[in flow]device : %s\n",start->ifname);   
        printf("\t[in flow]ID: %u\n",start->flowID);   
        printf("\t[in flow]protocol: 0x%x\n\n",start->protocol);   
	}
}

int main()
{
	update_outflow();
	update_inflow();
	return 0;
}

