/** Automatically generated file. DO NOT MODIFY */
package ac.ict.mobileinternet.flowmanagement;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}